package Quiz;

public class Reponse {

    String reponse1;
    String reponse2;
    String reponse3;
    String reponse4;
    int bonneReponse;

    public Reponse(String reponse1, String reponse2 , String reponse3, String reponse4, int bonneReponse) {
        this.reponse1 = reponse1;
        this.reponse2 = reponse2;
        this.reponse3 = reponse3;
        this.reponse4 = reponse4;
        this.bonneReponse = bonneReponse;
    }
}
